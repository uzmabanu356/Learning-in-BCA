// Event Data Array
const events = [
    {
        image: "../media/home.jpeg"
    },
    { 

        image: "../media/home.jpeg"
    },
    {

        image: "../media/home.jpeg"
    },
    {

        image: "../media/home.jpeg"
    },
    {

        image: "../media/home.jpeg"
    },
    {

        image: "../media/home.jpeg"
    },
    {

        image: "../media/home.jpeg"
    },
    {

        image: "../media/home.jpeg"

    }

];

const cardContainer = document.getElementById("cardContainer");

// Function to Dynamically Generate Cards
events.forEach(event => {
    const card = document.createElement("div");
    card.className = "cards";
    card.innerHTML = `
        <img src="${event.image}" alt="Event Image" class="event-image">
    `;
    cardContainer.appendChild(card);
});
